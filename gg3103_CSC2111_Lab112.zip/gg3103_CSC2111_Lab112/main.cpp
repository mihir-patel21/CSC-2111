#include <iostream>
#include "dataType.h" 
using namespace std;

int main()
{
    dataType *dt1 = new dataType();
    cout << "Data is: " << endl;
    dt1 -> printData();
    cout << endl;
    dt1 -> isLeapYear();
    cout << endl;
    dataType *dt2 = new DataType(3,6,2021);
    cout << "Date is: " << endl;
    dt2 -> printData();
    cout << endl;
    dt2 -> isLeapYear();
    cout << endl;
    dt2 -> setDate(3,7,2020);
    cout << "Data is: " << endl;
    dt2-> printDate();
    cout << endl;
}