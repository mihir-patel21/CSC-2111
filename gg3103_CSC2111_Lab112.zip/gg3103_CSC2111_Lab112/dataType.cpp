#include <iostream>
#include "dataType.h"

using namespace std;

void dataType::setDate(int month, int day, int year)
{
    while(month < 1 || month > 12)
    {
        cout << "Enter month" << month << "is wrong" << endl;
        cout << "Enter correct month" << endl;
        cin >> month;
    }

    dMonth = month;

    while (day < 1 || day > 31)
    {
        cout << "Enter date" << day << "is wrong" << endl;
        cout << "Enter correct date" << endl;
        cin >> day;
    }

    dDay = day;
    int count_digits = 0;
    int flag = 0;
    int year1;

    while(flag == 0)
    {
        year1 = year;
        count_digits = 0;
        while(year)
        {
            year /= 10;
            count_digits++;
        }

        if(count_digits != 4)
        {
            cout << "Enter year" << year1 << "is wrong" << endl;
            cout << "Enter correct year" << endl;
            cin >> year;
            flag = 0;
        }

        else
        {
            flag = 1;
        }
    }

    dYear = year1;
}

int dataType:: getDay() const
{
    return dDay;
}

int dataType:: getMonth() const
{
    return dMonth;
}

int dataType:: getYear() const
{
    return dYear;
}

void dataType:: printData() const
{
    cout << dMonth << "/" << dDay << "/" << dYear << endl;
}

void dataType:: isLeapYear() const
{
    if(dYear%400 == 0)
    {
        cout << dYear << " is leap year." << endl;
    }

    else if(dYear%100 == 0)
    {
        cout << dYear << " is a leap year." << endl;
    }
    else if(dYear%4 == 0)
    {
        cout << dYear << " is a leap year." << endl;
    }
}

dataType::dataType(int month, int day, int year)
{
    while(month <1 || month > 12)
    {
        cout << "Enter month" << month << " is wrong" << endl;
        cout << "Enter correct month" << endl;
        cin >> month;
    }
    dMonth = month;

     while (day < 1 || day > 31)
    {
        cout << "Enter date" << day << "is wrong" << endl;
        cout << "Enter correct date" << endl;
        cin >> day;
    }

    dDay = day;
    int count_digits = 0;
    int flag = 0;
    int year1;

    while(flag == 0)
    {
        year1 = year;
        count_digits = 0;
        while(year)
        {
            year /= 10;
            count_digits++;
        }

        if(count_digits != 4)
        {
            cout << "Enter year" << year1 << "is wrong" << endl;
            cout << "Enter correct year" << endl;
            cin >> year;
            flag = 0;
        }

        else
        {
            flag = 1;
        }
    }

    dYear = year1;
}