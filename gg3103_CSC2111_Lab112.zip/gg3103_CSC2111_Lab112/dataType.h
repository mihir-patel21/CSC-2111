#ifndef dataType_H
#define dataType_H

class dataType
{
    public:
    void setData(int month,int day, int year);
    int getDay() const;
    int getMonth() const;
    int getYear() const;
    void printDate() const;
    void isLeapYear() const;
    dataType(int month = 1, int day = 1, int year = 1900);

    private:
    int dMonth;
    int dDay;
    int dYear;
};

#endif