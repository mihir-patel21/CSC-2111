//************************************************************
// Author: D.S. Malik
//
// class studentType
// This class specifies the members to implement a student's
// information.
//************************************************************

#ifndef H_studentType
#define H_studentType

#include <fstream>
#include <string>
#include "personType.h"
#include "courseType.h"

using namespace std;

class studentType: public personType
{
public:
  virtual void print() = 0;
  virtual void calculateGPA() = 0;
  void setID(long id);
  void setCourse(const string c[], int noOfC);
  void setGrades(const char cG[], int noOfC);
  void getID();
  void getCourse(string c[], int noOfC);
  void getGrades(char gG[], int noOfC);
  void studentType(string fName = "", string lastName = "", long id, string c[] = NULL, char cG[] = NULL, int noOfC = 0);
  private:
  long studentId;
  string courses[6];
  char courseGrade[6];
  int noOfCourse;

#endif
