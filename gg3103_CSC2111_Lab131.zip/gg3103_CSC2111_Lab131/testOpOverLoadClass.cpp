
#include <iostream>                                 //Line 1
#include "rectangleType.h"                          //Line 2
   
using namespace std;                                //Line 3

int main()                                          //Line 4
int main()
{

RectangleType first, second, third;


cout<<"\n Enter first rectangle information: \n";
cin>>first;
cout<<"\n Enter second rectangle information: \n";
cin>>second;


cout<<"\n First Rectangle: \n"<<first<<endl;
cout<<"\n Second Rectangle: \n"<<second<<endl;



third = first + second;
cout<<"\n ******************** After first + second ******************** ";
cout<<third<<endl;
third = first - second;
cout<<"\n ******************** After first - second ******************** ";
cout<<third<<endl;
cout<<"\n ******************** After ++first ******************** ";
++first;
cout<<first<<endl;
cout<<"\n ******************** Compares first == second ******************** ";
if(first == second)
cout<<"\n First rectangle is equals to second.";
else
cout<<"\n First rectangle is not equals to second.";

cout<<"\n ******************** Compares first != second ******************** ";
if(first != second)
cout<<"\n First rectangle is not equals to second.";
else
cout<<"\n First rectangle is equals to second.";
return 0;
}