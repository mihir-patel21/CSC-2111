#ifndef H_rectangleType
#define H_rectangleType

class rectangleType
{
    int width;
    int height;

    public:
    RectangleTpye();
    friend ostream &operator <<(ostream &, RectangleType &);
    friend istream &operator >>(istream &, RectangleType &);
    RectangleType operator +(RectangleType);
    RectangleType operator -(RectangleType);
    void operator ++();
    bool operator ==(RectangleType);
    bool operator !=(RectangleType);
};

#endif
