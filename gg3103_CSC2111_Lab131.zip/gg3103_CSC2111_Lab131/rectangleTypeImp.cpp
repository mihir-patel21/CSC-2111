#include <iostream>
#include "rectangleType.h"

using namespace std;

RectangleType::RectangleType()
{
width = height = 0;
}


ostream &operator <<(ostream &os, RectangleType &rt)
{

os<<"\n Width: "<<rt.width<<"\n Height: "<<rt.height;

return os;
}


istream &operator >>(istream &in, RectangleType &rt)
{

cout<<"\n Enter Width: ";
in>>rt.width;
cout<<"\n Enter Height: ";
in>>rt.height;

return in;
}


RectangleType RectangleType::operator +(RectangleType rt)
{

RectangleType newRT;
newRT.width = width + rt.width;

newRT.height = height + rt.height;
return newRT;
}


RectangleType RectangleType::operator -(RectangleType rt)
{
RectangleType newRT;
newRT.width = width - rt.width;
newRT.height = height - rt.height;
return newRT;
}

void RectangleType::operator ++()
{
++width;
++height;
}


bool RectangleType::operator ==(RectangleType rt)
{

if(rt.width == width && rt.height == height)
return true;


else
return false;
}


bool RectangleType::operator !=(RectangleType rt)
{

if(rt.width != width || rt.height != height)
return true;


else
return false;
}
