//personTypeImp.cpp

#include <iostream>
#include <string>
#include "personType.h"

using namespace std;

void personType::print() const
{
    cout << firstName << " " << lastName;
}

void personType::setFirstName(string fname)
{
    firstName = fname;
}
void personType::setLastName(string lname)
{
    lastName = lname;
}

string personType::getFirstName() const
{
    return firstName;
}

string personType::getLastName() const
{
    return lastName;
}

bool personType::isFirstNameSame(const string fname)
{
    if(firstName.compare(fname)==0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool personType::isLastNameSame(const string lname)
{
    if(lastName.compare(lname) == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

