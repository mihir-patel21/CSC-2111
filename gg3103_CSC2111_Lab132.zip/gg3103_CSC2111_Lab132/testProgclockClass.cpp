//**********************************************************
// Author: D.S. Malik
//
// This program shows how to use the class clockType.
//**********************************************************
  
#include <iostream>                                  //Line 1
#include "newClock.h"                                //Line 2

using namespace std;                                 //Line 3

int main()                                           //Line 4
{
   cout << "\n\n\tA Program to check the functionality"
       << "\n\tof the class clockType" << endl;

   clockType myClock( 23, 45, 12 );
   clockType yourClock;

   char choice;

   cout << "\n\tMy Clock: " << myClock;

   cout << "\n\tEnter the hours, minutes and seconds of your clock: ";
   cin >> yourClock;

   do
   {
       cout << "\n\n\t\t\tM E N U";
       cout << "\n\n\t Operation >\t: > ";
       cout << "\n\tOperation <\t: < ";
       cout << "\n\tOperation ==\t: == ";
       cout << "\n\tOperation !=\t: !";
       cout << "\n\tOperation >=\t: 1";
       cout << "\n\tOperation <=\t: 2";
       cout << "\n\tPre-Increment\t: 3";
       cout << "\n\tPost-Increment\t: 4";
       cout << "\n\tQuit\t: Q";

       cout << "\n\n\tPlease enter your choice: ";
           cin >> choice;

       if ( choice > 91 )
           choice -= 32;

       switch( choice )
       {
       case '>' : cout << "\n\tMy Clock > your clock is ";
           if ( myClock > yourClock )
               cout << "true";
           else
               cout << "false";
           break;

       case '<' : cout << "\n\tMy Clock < your clock is ";
           if( myClock < yourClock )
               cout << "true";
           else
               cout << "false";
           break;

       case '=' : cout << "\n\tMy Clock == your clock is";
           if( myClock == yourClock )
               cout << "True";
           else
               cout << "false";
           break;
      
       case '!' : cout << "\n\tMy Clock != your clock is";
           if( myClock != yourClock )
               cout << "true";
           else
               cout << "false";
           break;

       case '1' : cout << "\n\tMy Clock >= your clock is";
           if( myClock >= yourClock )
               cout << "true";
           else
               cout << "false";
           break;

       case '2' : cout << "\n\tMy Clock <= your clock is";
           if( myClock <= yourClock)
               cout << "true";
           else
               cout << "false";
           break;

       case '3' : cout << ++yourClock;
           cout << "-- Pre-incremented";
               break;

       case '4' : cout << yourClock++;
           cout << "- Post-incremented";
               break;
       }

   }while (choice != 'Q');

   cout << "\n\n\t";
   return 0;
}                                             

